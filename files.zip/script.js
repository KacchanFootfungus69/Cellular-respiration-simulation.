const stages = [
    {
        name: "Glycolysis",
        location: "Cytoplasm",
        visual: "🍬",
        description: "Breaking down glucose",
        explanation:
            "One glucose molecule (6 carbons) is split into two pyruvate molecules (3 carbons each). The process uses 2 ATP and produces 4 ATP, giving a net gain of 2 ATP and 2 NADH.",
        products: "2 Pyruvate, 2 ATP (net), 2 NADH",
        atp: 2, nadh: 2, fadh: 0, co2: 0
    },
    {
        name: "Pyruvate Oxidation",
        location: "Mitochondrial Matrix",
        visual: "🧬",
        description: "Preparing pyruvate",
        explanation:
            "The two pyruvate molecules are converted into two acetyl-CoA molecules. This produces 2 NADH and releases 2 CO₂.",
        products: "2 Acetyl-CoA, 2 NADH, 2 CO₂",
        atp: 0, nadh: 2, fadh: 0, co2: 2
    },
    {
        name: "Krebs Cycle",
        location: "Mitochondrial Matrix",
        visual: "🔄",
        description: "Harvesting energy",
        explanation:
            "The two acetyl-CoA molecules enter the Krebs cycle. Across two turns, the cycle produces 2 ATP, 6 NADH, 2 FADH₂, and 4 CO₂.",
        products: "2 ATP, 6 NADH, 2 FADH₂, 4 CO₂",
        atp: 2, nadh: 6, fadh: 2, co2: 4
    },
    {
        name: "Electron Transport Chain",
        location: "Inner Mitochondrial Membrane",
        visual: "⚡",
        description: "Producing most of the ATP",
        explanation:
            "NADH and FADH₂ deliver electrons to the electron transport chain. Their energy helps pump protons across the inner mitochondrial membrane. Protons flow back through ATP synthase, producing ATP. Oxygen accepts the electrons at the end and combines with protons to form water.",
        products: "About 26–28 ATP and H₂O",
        // NADH and FADH₂ are used up here, so they drop back to 0
        atp: 28, nadh: -10, fadh: -2, co2: 0
    }
];

const LAST = stages.length - 1;
let currentStage = 0;

const $ = (id) => document.getElementById(id);

function showStage(index) {
    currentStage = index;
    const stage = stages[index];

    $("stageName").textContent = stage.name;
    $("location").textContent = stage.location;
    $("visual").textContent = stage.visual;
    $("description").textContent = stage.description;
    $("explanation").textContent = stage.explanation;
    $("products").textContent = stage.products;

    updateCounters();

    // Highlight the active stage button
    document.querySelectorAll(".stage-buttons button").forEach((btn, i) => {
        btn.classList.toggle("active", i === index);
        btn.setAttribute("aria-current", i === index ? "step" : "false");
    });

    const next = $("nextButton");
    const done = index === LAST;
    next.textContent = done ? "Simulation Complete!" : "Next Stage →";
    next.disabled = done;
}

function updateCounters() {
    let atp = 0, nadh = 0, fadh = 0, co2 = 0;

    for (let i = 0; i <= currentStage; i++) {
        atp += stages[i].atp;
        nadh += stages[i].nadh;
        fadh += stages[i].fadh;
        co2 += stages[i].co2;
    }

    // Real yield varies by cell type, so the final total is a range (30–32)
    $("atp").textContent = currentStage === LAST ? "30–32" : atp;
    $("nadh").textContent = nadh;
    $("fadh").textContent = fadh;
    $("co2").textContent = co2;
}

function nextStage() {
    if (currentStage < LAST) showStage(currentStage + 1);
}

function resetSimulation() {
    showStage(0);
}

// Wire up buttons here instead of inline onclick attributes
document.querySelectorAll(".stage-buttons button").forEach((btn) => {
    btn.addEventListener("click", () => showStage(Number(btn.dataset.stage)));
});
$("nextButton").addEventListener("click", nextStage);
$("resetButton").addEventListener("click", resetSimulation);

showStage(0);
